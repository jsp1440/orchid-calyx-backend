import os
from fastapi import FastAPI

from app.database import engine
from app.migrations.run_migrations import run_migrations
from app.api.router import router

app = FastAPI(title="Orchid Judge App")

# v1.1: For dev/demo, we can auto-create missing tables.
# In production, prefer explicit migrations (e.g., Alembic) and set AUTO_CREATE_TABLES=0.
if os.getenv("AUTO_CREATE_TABLES", "1") == "1":
    run_migrations(engine)

app.include_router(router)

@app.get("/")
def root():
    return {"status": "ok"}
