# Orchid Judge App (v1) — Show Ops + Volunteers

Standalone backend service for orchid show operations and volunteer management.
This is **not** an AOS-sanctioned tool. It is designed to help orchid societies
run shows smoothly (and optionally prepare for judging workflows later).

## Stack
- FastAPI
- SQLAlchemy (2.x)
- PostgreSQL (Neon)
- Header-based admin key (v1)

## Quick Start (Replit)
1. Upload this ZIP to a new Replit
2. Set environment variables (Secrets) from `.env.example`
   - `DATABASE_URL`
   - `ORCHID_JUDGE_ADMIN_KEY`
3. Click **Run**
4. Open: `/docs`

Migrations run automatically on startup (v1 uses `create_all`).

## Authentication (Admin)
Admin-only endpoints require header:

`X-Orchid-Admin-Key: <ORCHID_JUDGE_ADMIN_KEY>`

Public volunteer signup does **not** require auth.

## Core Endpoints (v1)
### Admin
- `POST /api/orgs`
- `POST /api/shows`
- `POST /api/shows/{show_id}/zones`
- `POST /api/shows/{show_id}/training-assets`
- `POST /api/shows/{show_id}/volunteer-roles`
- `POST /api/shows/{show_id}/volunteer-shifts`
- `GET  /api/shows/{show_id}/roster`
- `PATCH /api/signups/{signup_id}/status`

### Public
- `POST /api/public/shifts/{shift_id}/signup`

## Next Steps
- “Show Setup Wizard” templates (FCOS small-show presets)
- Offline fallback (queued check-ins)
- QR/badge printing
- Judging Academy content + practice plan


## Notes (v1.1 improvements)
- Centralized admin auth in `app/security.py`.
- Added PATCH/DELETE endpoints for operational resources (zones/vendors/training/roles/shifts).
- Added composite uniqueness constraints and indexes in ORM models (effective on fresh DBs).
- `AUTO_CREATE_TABLES=1` will create missing tables on boot (dev/demo). For production schema evolution, use Alembic.
